# Συνάντηση

A JavaScript community website for people in Greece. This starter includes account registration/login, age-band-separated discovery and messaging, block/report tools, and an optional Stripe Checkout donation flow.

## Important safety and launch notes

- This is a starter implementation, not a fully moderated production social network.
- Registration uses self-declared age bands. That is **not** reliable age verification. Before public launch, add a legally reviewed age-assurance process, safeguarding policy, trained moderation, a published privacy notice, retention/deletion procedures, and a clear contact channel.
- The app separates 13–15, 16–17 and 18+ accounts. It does not allow cross-band discovery or messaging. Do not weaken this rule.
- Do not display exact location, live location, phone numbers, home addresses, schools, or social handles.
- Do not let minors make donations or enter payment details. The donation UI currently requires login but does not enforce adult-only payment. Before enabling donations publicly, add a robust adult-only flow and legal review. For a real launch, have a parent/guardian or organization manage fundraising.
- The example charity names are not endorsements or proof of partnership. Obtain written authorization from each organization before accepting donations in its name. Until then, keep `DONATION_ENABLED=false`.
- Reports are stored in SQLite, but there is no moderator dashboard yet. Do not launch publicly until reports can be reviewed promptly and unsafe accounts can be suspended.
- Add CSRF protection, email verification, account recovery, stronger anti-spam controls, audit logging, backups, and a moderation workflow before production.
- Use HTTPS in production. Never commit `.env`, database files, passwords, or Stripe secrets to GitHub.

## Requirements

- Node.js 20 or newer
- npm

## Run locally

```bash
npm install
cp .env.example .env
```

Set a unique long `SESSION_SECRET` in `.env`, then:

```bash
npm run dev
```

Open `http://localhost:3000`.

On Windows, copy `.env.example` to `.env` manually if `cp` is unavailable.

## Project structure

```text
synantisi/
├── public/
│   ├── app.js
│   ├── index.html
│   └── styles.css
├── data/                 # created automatically; do not commit
├── .env.example
├── .gitignore
├── package.json
├── README.md
└── server.js
```

## Donations (optional)

Payments are disabled by default. To enable them:

1. Establish a formal fundraising agreement with the named charity or use an organization-owned payment account.
2. Complete legal, tax, consumer-protection and safeguarding review for Greece/EU.
3. Configure Stripe Checkout and webhook verification in a production-ready implementation.
4. Add adult-only donation eligibility and a clear receipt/refund/support process.
5. Only then set `DONATION_ENABLED=true`, `STRIPE_SECRET_KEY`, `PUBLIC_URL`, and deploy with HTTPS.

This starter creates Stripe Checkout sessions but does not implement webhook-based payment reconciliation, charity payout automation, or donation receipts. Do not claim a donation is completed based only on the browser return URL.

## Deployment

Deploy to a Node.js host that supports persistent disk storage. The SQLite database and session database live in `data/`; ephemeral filesystems will lose accounts/messages after redeploy. Configure a persistent volume mounted at the app's `data` directory, set `NODE_ENV=production`, `SESSION_SECRET`, and `PUBLIC_URL`, and use HTTPS. Run `npm start`.

Before public launch, have the full service reviewed for Greek/EU privacy, consumer, fundraising, child-safety and platform obligations.
