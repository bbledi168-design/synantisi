const $ = (s) => document.querySelector(s);
const regions = ["Αττική","Κεντρική Μακεδονία","Κρήτη","Θεσσαλία","Δυτική Ελλάδα","Ήπειρος","Πελοπόννησος","Στερεά Ελλάδα","Ανατολική Μακεδονία και Θράκη","Δυτική Μακεδονία","Ιόνια Νησιά","Βόρειο Αιγαίο","Νότιο Αιγαίο"];
$("#regionSelect").innerHTML = regions.map(r => `<option>${r}</option>`).join("");
let me = null, activePerson = null, refreshTimer = null;
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function toast(message) { const el=$("#toast"); el.textContent=message; el.classList.add("show"); setTimeout(()=>el.classList.remove("show"),2800); }
async function api(url, options={}) {
  const response = await fetch(url, { credentials:"same-origin", headers:{"Content-Type":"application/json",...(options.headers||{})}, ...options });
  const data = await response.json().catch(()=>({}));
  if (!response.ok) throw new Error(data.error || "Κάτι πήγε στραβά.");
  return data;
}
function openModal(tab="register") { $("#authModal").classList.remove("hidden"); switchTab(tab); }
function closeModal() { $("#authModal").classList.add("hidden"); }
function switchTab(tab) {
  document.querySelectorAll(".tab").forEach(b=>b.classList.toggle("active",b.dataset.tab===tab));
  $("#registerForm").classList.toggle("hidden",tab!=="register");
  $("#loginForm").classList.toggle("hidden",tab!=="login");
  $("#authMessage").textContent="";
}
$("#headerAuth").onclick=()=>me?showApp():openModal("login");
$("#heroJoin").onclick=()=>me?showApp():openModal("register");
$("#closeModal").onclick=closeModal;
$("#authModal").addEventListener("click",e=>{if(e.target===$("#authModal"))closeModal();});
document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>switchTab(b.dataset.tab));

$("#registerForm").onsubmit=async e=>{
  e.preventDefault(); const f=new FormData(e.currentTarget);
  const payload=Object.fromEntries(f.entries());
  payload.confirmAge=f.get("confirmAge")==="on"; payload.acceptRules=f.get("acceptRules")==="on";
  try { const d=await api("/api/register",{method:"POST",body:JSON.stringify(payload)}); me=d.user; closeModal(); showApp(); toast("Ο λογαριασμός δημιουργήθηκε!"); }
  catch(err){$("#authMessage").textContent=err.message;}
};
$("#loginForm").onsubmit=async e=>{
  e.preventDefault(); const payload=Object.fromEntries(new FormData(e.currentTarget).entries());
  try {const d=await api("/api/login",{method:"POST",body:JSON.stringify(payload)});me=d.user;closeModal();showApp();}
  catch(err){$("#authMessage").textContent=err.message;}
};
async function boot(){
  try { const d=await api("/api/me"); me=d.user; if(me) showApp(); } catch {}
  try {const c=await api("/api/config"); if(c.donationEnabled) $("#donateStatus").textContent="Οι πληρωμές γίνονται με ασφάλεια μέσω Stripe."; } catch {}
  const p=new URLSearchParams(location.search).get("donation");
  if(p==="success") toast("Ευχαριστούμε! Έλεγξε την επιβεβαίωση πληρωμής.");
  if(p==="cancelled") toast("Η δωρεά ακυρώθηκε.");
}
function showApp(){
  $("#appShell").classList.remove("hidden");
  $("#welcomeName").textContent=me.display_name;
  $("#profileName").textContent=me.display_name;
  $("#profileInitial").textContent=me.display_name.slice(0,1).toUpperCase();
  $("#profileMeta").textContent=`${me.age_band} · ${me.region}`;
  $("#profileBio").textContent=me.bio || "Δεν έχει προστεθεί περιγραφή.";
  $("#headerAuth").textContent="Ο λογαριασμός μου";
  $("#appShell").scrollIntoView({behavior:"smooth",block:"start"});
  loadPeople();
}
async function loadPeople(){
  try{
    const d=await api("/api/people");
    $("#peopleList").innerHTML=d.people.length?d.people.map(p=>`<div class="person ${activePerson?.id===p.id?"selected":""}" data-id="${p.id}"><div class="person-initial">${esc(p.display_name.slice(0,1).toUpperCase())}</div><div class="person-info"><b>${esc(p.display_name)}</b><small>${esc(p.region)} · ${esc(p.age_band)}</small></div><span>›</span></div>`).join(""):`<div class="empty-state">Δεν υπάρχουν ακόμη άλλα μέλη στην ομάδα σου. Δοκίμασε αργότερα.</div>`;
    document.querySelectorAll(".person").forEach(el=>el.onclick=()=>selectPerson(d.people.find(p=>p.id===Number(el.dataset.id))));
  }catch(e){toast(e.message);}
}
async function selectPerson(person){
  activePerson=person; $("#chatTitle").textContent=person.display_name;
  $("#messageForm input").disabled=false; $("#messageForm button").disabled=false;
  $("#blockButton").disabled=false; $("#reportButton").disabled=false;
  await loadMessages(); loadPeople();
}
async function loadMessages(){
  if(!activePerson)return;
  try{
    const d=await api(`/api/messages/${activePerson.id}`);
    $("#chatMessages").innerHTML=d.messages.length?d.messages.map(m=>`<div class="bubble ${m.sender_id===me.id?"mine":""}">${esc(m.body)}<time>${new Date(m.created_at+"Z").toLocaleString("el-GR",{dateStyle:"short",timeStyle:"short"})}</time></div>`).join(""):`<div class="empty-state">Πες ένα γεια για να ξεκινήσει η συζήτηση!</div>`;
    $("#chatMessages").scrollTop=$("#chatMessages").scrollHeight;
  }catch(e){toast(e.message);activePerson=null;}
}
$("#messageForm").onsubmit=async e=>{
  e.preventDefault(); if(!activePerson)return;
  const input=e.currentTarget.elements.body, body=input.value.trim(); if(!body)return;
  try{await api("/api/messages",{method:"POST",body:JSON.stringify({receiverId:activePerson.id,body})});input.value="";await loadMessages();}
  catch(err){toast(err.message);}
};
$("#refreshPeople").onclick=loadPeople;
$("#logoutButton").onclick=async()=>{await api("/api/logout",{method:"POST"});location.reload();};
$("#blockButton").onclick=async()=>{
  if(!activePerson||!confirm(`Να αποκλειστεί ο χρήστης ${activePerson.display_name};`))return;
  try{await api(`/api/block/${activePerson.id}`,{method:"POST"});activePerson=null;$("#chatTitle").textContent="Επίλεξε ένα άτομο";$("#chatMessages").innerHTML='<div class="empty-state">Ο χρήστης αποκλείστηκε.</div>';$("#messageForm input").disabled=true;$("#messageForm button").disabled=true;$("#blockButton").disabled=true;$("#reportButton").disabled=true;loadPeople();toast("Ο χρήστης αποκλείστηκε.");}catch(e){toast(e.message);}
};
$("#reportButton").onclick=async()=>{
  if(!activePerson)return;
  const reason=prompt("Γιατί θέλεις να αναφέρεις αυτόν τον χρήστη; (π.χ. παρενόχληση, spam, ακατάλληλο περιεχόμενο)");
  if(!reason)return;
  const details=prompt("Πρόσθετες πληροφορίες (προαιρετικά):")||"";
  try{await api(`/api/report/${activePerson.id}`,{method:"POST",body:JSON.stringify({reason,details})});toast("Η αναφορά καταχωρίστηκε.");}
  catch(e){toast(e.message);}
};
$("#donateButton").onclick=async()=>{
  if(!me){openModal("login");toast("Συνδέσου για να συνεχίσεις.");return;}
  try{const d=await api("/api/donations/checkout",{method:"POST",body:JSON.stringify({charity:$("#charity").value,amount:Number($("#amount").value)})});location.href=d.url;}
  catch(e){$("#donateStatus").textContent=e.message;toast(e.message);}
};
boot();
