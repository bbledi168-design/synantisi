import "dotenv/config";
import express from "express";
import helmet from "helmet";
import session from "express-session";
import SQLiteStoreFactory from "connect-sqlite3";
import Database from "better-sqlite3";
import bcrypt from "bcryptjs";
import rateLimit from "express-rate-limit";
import Stripe from "stripe";
import path from "node:path";
import { fileURLToPath } from "node:url";
import fs from "node:fs";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dataDir = path.join(__dirname, "data");
fs.mkdirSync(dataDir, { recursive: true });

const app = express();
const db = new Database(path.join(dataDir, "synantisi.sqlite"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  display_name TEXT NOT NULL,
  age_band TEXT NOT NULL CHECK(age_band IN ('13-15','16-17','18+')),
  region TEXT NOT NULL,
  bio TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  sender_id INTEGER NOT NULL REFERENCES users(id),
  receiver_id INTEGER NOT NULL REFERENCES users(id),
  body TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS blocks (
  blocker_id INTEGER NOT NULL REFERENCES users(id),
  blocked_id INTEGER NOT NULL REFERENCES users(id),
  PRIMARY KEY(blocker_id, blocked_id)
);
CREATE TABLE IF NOT EXISTS reports (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  reporter_id INTEGER NOT NULL REFERENCES users(id),
  reported_id INTEGER NOT NULL REFERENCES users(id),
  reason TEXT NOT NULL,
  details TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);

const SQLiteStore = SQLiteStoreFactory(session);
const isProduction = process.env.NODE_ENV === "production";
app.disable("x-powered-by");
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "20kb" }));
app.use(session({
  store: new SQLiteStore({ db: "sessions.sqlite", dir: dataDir }),
  secret: process.env.SESSION_SECRET || "development-only-change-this-secret",
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: "lax",
    secure: isProduction,
    maxAge: 1000 * 60 * 60 * 24 * 7
  }
}));

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 12, standardHeaders: true, legacyHeaders: false });
const messageLimiter = rateLimit({ windowMs: 60 * 1000, limit: 20, standardHeaders: true, legacyHeaders: false });
const stripe = process.env.STRIPE_SECRET_KEY ? new Stripe(process.env.STRIPE_SECRET_KEY) : null;

const regions = [
  "Αττική", "Κεντρική Μακεδονία", "Κρήτη", "Θεσσαλία", "Δυτική Ελλάδα",
  "Ήπειρος", "Πελοπόννησος", "Στερεά Ελλάδα", "Ανατολική Μακεδονία και Θράκη",
  "Δυτική Μακεδονία", "Ιόνια Νησιά", "Βόρειο Αιγαίο", "Νότιο Αιγαίο"
];
const bands = ["13-15", "16-17", "18+"];

function clean(value, max = 500) {
  return String(value ?? "").trim().slice(0, max);
}
function currentUser(req) {
  if (!req.session.userId) return null;
  return db.prepare("SELECT id, username, display_name, age_band, region, bio FROM users WHERE id=?")
    .get(req.session.userId) || null;
}
function requireAuth(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: "Συνδέσου πρώτα." });
  next();
}
function canConnect(a, b) {
  return !!a && !!b && a.id !== b.id && a.age_band === b.age_band;
}
function isBlocked(a, b) {
  return !!db.prepare("SELECT 1 FROM blocks WHERE (blocker_id=? AND blocked_id=?) OR (blocker_id=? AND blocked_id=?)")
    .get(a, b, b, a);
}
function safeUser(u) {
  return { id: u.id, username: u.username, display_name: u.display_name, age_band: u.age_band, region: u.region, bio: u.bio };
}

app.get("/api/config", (_req, res) => {
  res.json({ donationEnabled: process.env.DONATION_ENABLED === "true" && !!stripe });
});
app.get("/api/me", (req, res) => res.json({ user: currentUser(req) }));

app.post("/api/register", authLimiter, async (req, res) => {
  const username = clean(req.body.username, 24).toLowerCase();
  const displayName = clean(req.body.displayName, 32);
  const password = String(req.body.password ?? "");
  const ageBand = clean(req.body.ageBand, 8);
  const region = clean(req.body.region, 60);
  const bio = clean(req.body.bio, 240);

  if (!/^[a-z0-9_]{3,24}$/.test(username)) return res.status(400).json({ error: "Το όνομα χρήστη χρειάζεται 3–24 λατινικούς χαρακτήρες, αριθμούς ή _." });
  if (displayName.length < 2) return res.status(400).json({ error: "Γράψε ένα όνομα εμφάνισης." });
  if (password.length < 10) return res.status(400).json({ error: "Ο κωδικός πρέπει να έχει τουλάχιστον 10 χαρακτήρες." });
  if (!bands.includes(ageBand)) return res.status(400).json({ error: "Επίλεξε έγκυρη ηλικιακή ομάδα." });
  if (!regions.includes(region)) return res.status(400).json({ error: "Επίλεξε περιοχή από τη λίστα." });
  if (req.body.confirmAge !== true || req.body.acceptRules !== true) return res.status(400).json({ error: "Χρειάζεται επιβεβαίωση ηλικιακής ομάδας και αποδοχή κανόνων." });

  try {
    const hash = await bcrypt.hash(password, 12);
    const result = db.prepare("INSERT INTO users (username,password_hash,display_name,age_band,region,bio) VALUES (?,?,?,?,?,?)")
      .run(username, hash, displayName, ageBand, region, bio);
    req.session.userId = Number(result.lastInsertRowid);
    res.status(201).json({ user: currentUser(req) });
  } catch (e) {
    if (String(e.message).includes("UNIQUE")) return res.status(409).json({ error: "Αυτό το όνομα χρήστη χρησιμοποιείται ήδη." });
    res.status(500).json({ error: "Δεν ήταν δυνατή η δημιουργία λογαριασμού." });
  }
});

app.post("/api/login", authLimiter, async (req, res) => {
  const username = clean(req.body.username, 24).toLowerCase();
  const password = String(req.body.password ?? "");
  const user = db.prepare("SELECT * FROM users WHERE username=?").get(username);
  if (!user || !(await bcrypt.compare(password, user.password_hash))) return res.status(401).json({ error: "Λάθος στοιχεία σύνδεσης." });
  req.session.userId = user.id;
  res.json({ user: currentUser(req) });
});
app.post("/api/logout", (req, res) => req.session.destroy(() => res.json({ ok: true })));

app.get("/api/people", requireAuth, (req, res) => {
  const me = currentUser(req);
  const rows = db.prepare(`
    SELECT id, username, display_name, age_band, region, bio FROM users
    WHERE id != ? AND age_band = ?
    AND id NOT IN (SELECT blocked_id FROM blocks WHERE blocker_id=?)
    AND id NOT IN (SELECT blocker_id FROM blocks WHERE blocked_id=?)
    ORDER BY created_at DESC LIMIT 60
  `).all(me.id, me.age_band, me.id, me.id);
  res.json({ people: rows });
});

app.get("/api/messages/:userId", requireAuth, (req, res) => {
  const me = currentUser(req);
  const other = db.prepare("SELECT id, age_band FROM users WHERE id=?").get(Number(req.params.userId));
  if (!canConnect(me, other) || isBlocked(me.id, other.id)) return res.status(403).json({ error: "Η συνομιλία δεν είναι διαθέσιμη." });
  const messages = db.prepare(`
    SELECT id, sender_id, receiver_id, body, created_at FROM messages
    WHERE (sender_id=? AND receiver_id=?) OR (sender_id=? AND receiver_id=?)
    ORDER BY id DESC LIMIT 100
  `).all(me.id, other.id, other.id, me.id).reverse();
  res.json({ messages });
});

app.post("/api/messages", requireAuth, messageLimiter, (req, res) => {
  const me = currentUser(req);
  const receiverId = Number(req.body.receiverId);
  const body = clean(req.body.body, 1000);
  const other = db.prepare("SELECT id, age_band FROM users WHERE id=?").get(receiverId);
  if (!body) return res.status(400).json({ error: "Το μήνυμα είναι κενό." });
  if (!canConnect(me, other) || isBlocked(me.id, other.id)) return res.status(403).json({ error: "Δεν επιτρέπεται αυτή η συνομιλία." });
  const result = db.prepare("INSERT INTO messages (sender_id,receiver_id,body) VALUES (?,?,?)").run(me.id, other.id, body);
  res.status(201).json({ message: db.prepare("SELECT * FROM messages WHERE id=?").get(result.lastInsertRowid) });
});

app.post("/api/block/:userId", requireAuth, (req, res) => {
  const otherId = Number(req.params.userId);
  if (!Number.isInteger(otherId) || otherId === req.session.userId) return res.status(400).json({ error: "Μη έγκυρος χρήστης." });
  db.prepare("INSERT OR IGNORE INTO blocks (blocker_id,blocked_id) VALUES (?,?)").run(req.session.userId, otherId);
  res.json({ ok: true });
});

app.post("/api/report/:userId", requireAuth, (req, res) => {
  const otherId = Number(req.params.userId);
  const reason = clean(req.body.reason, 60);
  const details = clean(req.body.details, 1000);
  if (!Number.isInteger(otherId) || otherId === req.session.userId || !reason) return res.status(400).json({ error: "Συμπλήρωσε τον λόγο αναφοράς." });
  db.prepare("INSERT INTO reports (reporter_id,reported_id,reason,details) VALUES (?,?,?,?)")
    .run(req.session.userId, otherId, reason, details);
  res.status(201).json({ ok: true });
});

app.post("/api/donations/checkout", requireAuth, async (req, res) => {
  if (process.env.DONATION_ENABLED !== "true" || !stripe) return res.status(503).json({ error: "Οι δωρεές δεν έχουν ενεργοποιηθεί ακόμη." });
  // Replace these example entries only with organizations that have formally authorized this fundraiser.
  const charities = {
    "hamogelo": { name: "Το Χαμόγελο του Παιδιού", url: "https://www.hamogelo.gr/" },
    "arsis": { name: "ΑΡΣΙΣ", url: "https://arsis.gr/" }
  };
  const charity = charities[clean(req.body.charity, 30)];
  const amount = Number(req.body.amount);
  if (!charity || ![5, 10, 20, 50].includes(amount)) return res.status(400).json({ error: "Μη έγκυρη επιλογή δωρεάς." });
  try {
    const base = process.env.PUBLIC_URL || "http://localhost:3000";
    const checkout = await stripe.checkout.sessions.create({
      mode: "payment",
      line_items: [{
        price_data: {
          currency: "eur",
          product_data: { name: `Δωρεά προς ${charity.name}`, description: "Η πληρωμή διεκπεραιώνεται από Stripe." },
          unit_amount: amount * 100
        },
        quantity: 1
      }],
      success_url: `${base}/?donation=success`,
      cancel_url: `${base}/?donation=cancelled`,
      metadata: { charity: req.body.charity, userId: String(req.session.userId) }
    });
    res.json({ url: checkout.url });
  } catch {
    res.status(500).json({ error: "Δεν ήταν δυνατή η δημιουργία πληρωμής." });
  }
});

app.use(express.static(path.join(__dirname, "public")));
app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`Synantisi running on http://localhost:${port}`));
